// This is the Link API
import Link from 'next/link';

// Pass this content as 'props' to child components
const About = props => (
    <div>
      <p>About Next.js</p>
    </div>
  );
  
  export default About;