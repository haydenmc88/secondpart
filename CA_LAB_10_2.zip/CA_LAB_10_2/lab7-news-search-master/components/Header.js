const Header = () => (
    <div>
        <h2 className="title">Latest News </h2>
        <style jsx>{`


            h2.title {
                font-family: "verdana";
                color: #f5f5f5;
                padding: 5px;
                text-align: left;
                font-size: 3em;
            }

            div 
            {
                background-color: #689EB8;
            }

        `}</style>
    </div> 
 )
 
 export default Header;