// Import Dependencies
import React, { Component } from "react";

//
// Define SearchForm Class
//
export default class SearchForm extends Component {
  // constructor accepts props and initialises state
  constructor(props) {
    super(props);

    this.state = {};
  }

  //
  // an event handler for form submit
  //
  formSubmitted = event => {
    // Validate input value
    if (event.target.newsSource.value != "") {
      // setNewsSource is a function passed from parent (news page) via props
      // It is used as a way to pass the input value back up to the parent
      // This is called state lifting
      // see: https://reactjs.org/docs/lifting-state-up.html
      this.props.setNewsSource(event.target.newsSource.value);
    }
    // prevent page reload (prevent submit)
    event.preventDefault();
  };

  // Render the form
  render() {
    return (
      <div>
        {/* Search Input */}
        <div id="search">
          <h3>Choose a News source</h3>
          {/* Note event handler */}
          <form onSubmit={this.formSubmitted}>
            {/* The input field */}
            <input
              name="newsSource"
              placeholder="News Source name"
              type="text"
            />
            {/* Button click will trigger submit */}
            <button>Update News</button>
          </form>
          <style jsx>{`

              h3{
              font: "verdana";
              color: #698eb8;
              }
     
              input{
              /* border: 0.1em; */
             /* border-style: solid; */
              border-color: #ff5a60;
              font-family: verdana;
              border-right: none;
              /* font-size: 15px; */
             /*font-weight: bold; */
            padding: 0.6em;
              margin-bottom: 0.6em;
              text-align: center;
              background-color: #f3f4f6;
              color: #689eb8;
              
            }
            .input.placeholder {
              color: #689eb8;
            }

               button{
              /* border: 0.1em; */
             /* border-style: solid; */ 
             border-color: #ff5a60;
              font-family: verdana;
              /* font-size: 15px; */
             /*font-weight: bold; */
              padding: 0.6em;
              margin-bottom: 0.6em ;
              text-align: center;
              background-color: #f3f4f6;
              color: #689eb8;
              cursor: pointer;
              
            }

            button:hover{
              background-color: #ff5a60;
              transition: all ease-out 0.4s;	
              color: #f3f4f6;
              
            }

          `}</style>
        </div>
      </div>
    );
  }
}



































































/*// Import Dependencies
import React, { Component } from "react";
//import SearchForm from '../components/SearchFormSelect';

//
// Define SearchForm Class
//


export default class SearchForm extends React.Component {
  // constructor accepts props and initialises state
  constructor(props) {
    super(props);

    this.state = {};
  }

 
  // an event handler for form submit
  formSubmitted = event => {
    // Validate input value
    if (event.target.newsSource.value != "") {
      // setNewsSource is a function passed from parent (news page) via props
      // It is used as a way to pass the input value back up to the parent
      // This is called state lifting
      // see: https://reactjs.org/docs/lifting-state-up.html
      this.props.setNewsSource(event.target.newsSource.value);
    }
    // prevent page reload (prevent submit)
    event.preventDefault();
  };

  updateSearch(event) {
    this.setState({search: event.target.value});
  }

  // Render the form
  render() {
    let filteredNewsSource = this.props.articles;
    return (
      <div>
        {/* Search Input*//* }
        <div id="search">
          <h3>Search the latest News below by typing a news API source</h3>
          {/* Note event handler *//* }
          <form onSubmit={this.formSubmitted}>
            {/* The input field */  /*}
  
            
            <input
                 name="newsSource"
                 placeholder="News Source name"
                 type='text'
               
            />
            
            {/* Button click will trigger submit   */ /*}
            <button>Update News</button>
          </form>
          <style jsx>{`

              h3{
              font: "verdana";
              color: #698eb8;
              }
     
              input{
              /* border: 0.1em; */
             /* border-style: solid; */
              /*border-color: #ff5a60;
              font-family: verdana;
              border-right: none;
              /* font-size: 15px; */
             /*font-weight: bold; */
            /* padding: 0.6em;
              margin-bottom: 0.6em;
              text-align: center;
              background-color: #f3f4f6;
              color: #689eb8;
              
            }
            .input.placeholder {
              color: #689eb8;
            }

               button{
              /* border: 0.1em; */
             /* border-style: solid; */ 
             /* border-color: #ff5a60;
              font-family: verdana;
              /* font-size: 15px; */
             /*font-weight: bold; */
             /* padding: 0.6em;
              margin-bottom: 0.6em ;
              text-align: center;
              background-color: #f3f4f6;
              color: #689eb8;
              cursor: pointer;
              
            }

            button:hover{
              background-color: #ff5a60;
              transition: all ease-out 0.4s;	
              color: #f3f4f6;
              
            }

          `}</style>
        </div>
      
      </div>
       
      
    );

 }
} 




































/*                                SELECT DROPDOWN

I tried these options too but they did not seem to work. I researched Jed Watson 
and found his examples on github and youtube but they were no help. I also looked 
on the website for async select boxes and the results were not of use.
I tried using YARN also to perform this. */

/*import React from 'react';
import createClass from 'create-react-class';
import PropTypes from 'prop-types';
import Select from 'react-select';

const FLAVOURS = [
	{ label: 'Chocolate', value: 'chocolate' },
	{ label: 'Vanilla', value: 'vanilla' },
	{ label: 'Strawberry', value: 'strawberry' },
	{ label: 'Caramel', value: 'caramel' },
	{ label: 'Cookies and Cream', value: 'cookiescream' },
	{ label: 'Peppermint', value: 'peppermint' },
];

var MultiSelectField = createClass({
	displayName: 'MultiSelectField',
	propTypes: {
		label: PropTypes.string,
	},
	getInitialState () {
		return {
			removeSelected: true,
			disabled: false,
			crazy: false,
			stayOpen: false,
			value: [],
			rtl: false,
		};
	},
	handleSelectChange (value) {
		console.log('You\'ve selected:', value);
		this.setState({ value });
	},
	toggleCheckbox (e) {
		this.setState({
			[e.target.name]: e.target.checked,
		});
	},
	toggleRtl (e) {
		let rtl = e.target.checked;
		this.setState({ rtl });
	},

	render () {
		const { crazy, disabled, stayOpen, value } = this.state;
		const options = FLAVOURS;
		return (
			<div className="section">
				<h3 className="section-heading">{this.props.label} <a href="https://github.com/JedWatson/react-select/tree/v1.x/examples/src/components/Multiselect.js">(Source)</a></h3>
				<Select
					closeOnSelect={!stayOpen}
					disabled={disabled}
					multi
					onChange={this.handleSelectChange}
					options={options}
					placeholder="Select your favourite(s)"
          removeSelected={this.state.removeSelected}
					rtl={this.state.rtl}
					simpleValue
					value={value}
				/>

				<div className="checkbox-list">
					<label className="checkbox">
						<input type="checkbox" className="checkbox-control" name="removeSelected" checked={this.state.removeSelected} onChange={this.toggleCheckbox} />
						<span className="checkbox-label">Remove selected options</span>
					</label>
					<label className="checkbox">
						<input type="checkbox" className="checkbox-control" name="disabled" checked={this.state.disabled} onChange={this.toggleCheckbox} />
						<span className="checkbox-label">Disable the control</span>
					</label>
					<label className="checkbox">
						<input type="checkbox" className="checkbox-control" name="crazy" checked={crazy} onChange={this.toggleCheckbox} />
						<span className="checkbox-label">I don't like Chocolate (disabled the option)</span>
					</label>
					<label className="checkbox">
						<input type="checkbox" className="checkbox-control" name="stayOpen" checked={stayOpen} onChange={this.toggleCheckbox}/>
						<span className="checkbox-label">Stay open when an Option is selected</span>
					</label>
					<label className="checkbox">
						<input type="checkbox" className="checkbox-control" name="rtl" checked={this.state.rtl} onChange={this.toggleCheckbox} />
						<span className="checkbox-label">rtl</span>
					</label>
				</div>
			</div>
		);
	}
});
module.exports = MultiSelectField; */